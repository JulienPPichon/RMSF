import matplotlib.pyplot as plt
import sys
import os
import math


"""
Ce programme est conçu pour calculer le Root Mean Square Fluctuation (RMSF)
d'une protéine à partir de sa trajectoire.
Auteurs: MESSAD DIT MAHTAL Lynda & PICHON Julien.
"""


def get_arguments(args):
    """
    Cette fonction est en intéraction avec le shell pour
    vérifier si les arguments de la ligne de commande sont
    corrects. Dans le cas inverse elle ferme le script.
    """
    if len(args) != 2:
        print(len(args))
        sys.exit("Mauvais nombre d'arguments.\n")

    else:
        file_in = args[1]
        script = args[0]
    return file_in, script


def which_parametre():
    """
    Cette fonction a pour but de définir le paramètre d'exécution du programme.
    Elle ne prend pas d’argument mais nous retourne le paramètre choisit par
    l’utilisateur.
    """

    parametre = input("choisissez le type d'atome: \n 1: CA \n 2: ALL \n")
    if (str(parametre) != '1') and (str(parametre) != '2'):
        print("Mauvais parametre, Veuillez choisir 1 ou 2")
    if str(parametre) == '1':
        parametre = "CA"
    if str(parametre) == '2':
        parametre = "ALL"
    return parametre


def found_coordonnees(file_in, parametre):
    """
    Cette fonction prend en argument le fichier 'fichier.pdb'
    issue d'une trajectoire de dynamique moléculaire. Elle va
    parcourir le fichier et extraire les coordonnées des
    atomes CA pour chaque modèle. A la fin, elle va nous
    retourner une liste qui contient toutes les coordonnées
    ainsi que une liste d'indice des atomes.
    """
    with open(file_in) as file_in:

        i = 1
        model = -1
        liste_coord = []
        indice_atome = []
        liste_resultat = []
        max_indice = 0
        for ligne in file_in:
            if ligne.startswith("MODEL"):
                max_indice = 0
                i = 1
                model += 1
                Atom = 0
                liste_coord.append([])
                pass
            if parametre == "CA":
                if ligne.startswith("ATOM") and ligne[12:16].strip() == "CA":

                    x = float(ligne[30:38])
                    y = float(ligne[38:46])
                    z = float(ligne[46:54])
                    liste_coord[model].append([x, y, z])
                    i += 1
                    max_indice += 1
                    if len(indice_atome) < max_indice:
                        indice = int(ligne[6:11])
                        indice_atome.append(indice)

                liste_resultat.append(liste_coord)
                liste_resultat.append(indice_atome)

            if parametre == "ALL":
                if ligne.startswith("ATOM"):
                    x = float(ligne[30:38])
                    y = float(ligne[38:46])
                    z = float(ligne[46:54])
                    liste_coord[model].append([x, y, z])
                    i += 1
                    max_indice += 1
                    if len(indice_atome) < max_indice:
                        indice = int(ligne[6:11])
                        indice_atome.append(indice)

                liste_resultat.append(liste_coord)
                liste_resultat.append(indice_atome)
        return liste_resultat


def RMSF(list_coord):
    """
    La fonction RMSF permet de calculer le RMSF selon
    la relation vue en cours de Dynamique Moléculaire.
    """
    moy_all = []
    for element in range(len(list_coord[0])):
        moy_x = 0
        moy_y = 0
        moy_z = 0
        for atom in range(len(list_coord)):
            moy_x += list_coord[atom][element][0]
            moy_y += list_coord[atom][element][1]
            moy_z += list_coord[atom][element][2]
        moy_all.append([moy_x / len(list_coord), moy_y / len(list_coord), moy_z / len(list_coord)])

    RMSF = []
    for element in range(len(list_coord[0])):
        moy_x = 0
        moy_y = 0
        moy_z = 0
        mod = 0
        RMS = 0
        for atom in range(len(list_coord)):
            moy_x = list_coord[atom][element][0] - moy_all[element][0]
            moy_y = list_coord[atom][element][1] - moy_all[element][1]
            moy_z = list_coord[atom][element][2] - moy_all[element][2]
            mod += ((moy_x ** 2) + (moy_y ** 2) + (moy_z ** 2))
        RMS = ((math.sqrt(mod / len(list_coord)))*0.1)
        RMSF.append(RMS)
    return RMSF


def plot_RMSF(x, y):
    """
    La fonction prend 2 arguments: la liste des
    positions des atomes et leur RMSF. Par plot, on représente
    le RMSF en (nm) en fonction de la position du résidu.
    """
    plt.plot(x, y)
    plt.axis([0, 1434, 0, max(y)+0.01])
    plt.xlabel("Résidu")
    plt.ylabel("RMSF (nm)")
    if parametre.upper() == "CA":
        plt.title("RMSF des carbones alpha ")
    else:
        plt.title("RMSF de tous les atomes ")
    plt.show()


def exit_type():
    """
    Fonction sans arguments qui s’exécute en fermant la fenêtre du plot.
    Elle va nous permettre par un simple message affiché sur le terminal
    de choisir si oui on veut ou pas enregistrer le résultat des calculs
    du RMSF dans un fichier .txt
    """

    text = input("voulez-vous un fichier de sortie RMSF_CA/all.txt ? \n\
                 1: Oui \n 2: Non \n")
    if(str(text) != '1') and (str(text) != '2'):
        print("Veuillez répondre par 1 ou 2")
    if str(text) == '1':
        text = "RMSF"
        sortie = write_rmsf()
    if str(text) == '2':
        sys.exit("Thank you for using me '_' \n")
    return


def write_rmsf():
    """
    C’est une fonction sans arguments appelée par la fonction précédente.
    Cette fonction va sauvegarder le résultat des calculs dans un fichier .txt
    qui contiendra la position de l’atome  dans la protéine et son RMSF.
    Ce fichier sera enregistré dans le répertoire courant (d’où la fonction
    a été lancée) sous le nom RMSF_CA.txt ou RMSF_all.txt.
    """

    repertoire = os.getcwd()
    if parametre == "CA":
        name_file_out = "RMSF_outpout_CA.txt"
    else:
        name_file_out = "RMSF_output_all.txt"
    with open(name_file_out, "w") as file_out:
        i = 0
        file_out.write("Calcul du RMSF à partir de\
                       la trajectoire du fichier pdb\n")
        file_out.write("Programmme utilisé:{}\n\n".format(script))
        file_out.write("{:^10s} {:^10s}\n".format("position", "RMSF (nm)"))
        while i < len(position):
            file_out.write("{:^10d} {:^10f}\n".format(position[i], cal_RMSF[i]))
            i = i + 1
    print("le fichier {} a été sauvegardé dans {}".format(name_file_out, repertoire))
    print("Thank you for using me '_' \n")
    return file_out


# Programmme principal
if __name__ == "__main__":
    # Vérifier les arguments.
    file_in, script = get_arguments(sys.argv)

    # Choix du parametre.
    parametre = which_parametre()

    # Obtenir les coordonnées et les positions des atomes.
    results = found_coordonnees(file_in, parametre)
    coord = results[0]
    position = results[1]

    # Calcul du RMSF.
    cal_RMSF = RMSF(coord)

    # Représentation du RMSF.
    figure = plot_RMSF(position, cal_RMSF)

    # Sauvegarde du résultat.
    sortie = exit_type()
