﻿Ce programme python permet de calculer le RMSF. Il a était conçu par MESSAD DIT MAHTAL Lynda et PICHON Julien deux étudiants en master 1 Bioinformatique dans le cadre d’une unité d’enseignement: Dynamique des macromolécules.
 
	I.	But du script: 
Les fluctuations de la moyenne quadratique (RMSF) est une grandeur calculée qui nous permet d’obtenir des informations sur la flexibilité structurelle locale, la stabilité thermique et l'hétérogénéité des macromolécules. Ce script est conçu pour calculer le RMSF d’une protéine donnée à partir d’une trajectoire issue de la dynamique moléculaire.
 
	II.	Description du programme:

1.Généralités:
le programme «PDBtoRMSF.py» se base sur le langage python3 sous forme de différentes fonctions qui seront détaillées par la suite.
Ce programme s’appuie principalement sur l’équation de calcul du RMSF.


Il s’agit donc d’un programme qui peut être utilisé pour n’importe quelle protéine à condition d’avoir les bons fichiers.
Ce programme se constitue de 6 fonctions et d’un main (programme principal qui va assurer la bonne exécution des différentes fonctions). Au long de l’exécution des instruction devront être  fournies au programme selon votre but.

Le Main(Programme Principal):
il s’agit du corps du script qui va nous permettre d’exécuter les différentes fonctions.

   

	 •  Le programme s’exécute avec la ligne de commande suivante:

			     python3       PDBtoRMSF.py    MD_fit.pdb
					    
Cette commande va lancer le programme qui va fonctionner en appelant les différentes fonctions. 
 
2.Description des fonctions: on décrit ici les fonctions dans l’ordre d’exécution:

Fonction 1: get_arguments(args)
C’est la première fonction qui sera appelée par le Main. Cette fonction est en interaction avec le shell pour vérifier si les arguments de la ligne de commande sont corrects c-à-d 3 arguments et on extrait le fichier d’entrée qui est le fichier.pdb. Dans le cas inverse elle nous indique que le nombre d’arguments est invalide et ferme le programme.
Module requis: sys

Fonction 2: which_parametre()
Cette fonction a pour but de définir le paramètre de base de la suite du programme. Elle ne prend pas d’argument mais nous retourne le paramètre choisit par l’utilisateur.
L’appel de cette fonction fait apparaître sur le terminal un message qui vous demandera de choisir sur  quel type d’atome vous voulez travailler: 1: Atome CA, 2: All (c-à-d tous les atomes de la protéine), faudra donc répondre par 1 ou 2 pour définir le paramètre et passer à la suite de l’exécution.

Fonction 3: found_coordonnees(file_in, parametre)
Afin  de calculer le RMSF on a besoin de récupérer les coordonnées X, Y et Z des atomes. Ceci est donc faisable avec cette fonction. Elle prend en argument le fichier 'fichier,pdb' (retourner par la fonction1) issue d'une trajectoire de dynamique moléculaire ainsi que le paramètre d’exécution (retourner par la fonction2).  A la fin, elle va nous retourner une liste qui contient un tableau (coord) de toutes les coordonnées des atomes et un autre tableau (position) qui contient les indices de ces atomes.

Fonction 4: RMSF(list_coord)
c’est la fonction corps du programme qui permet de calculer le RMSF. Elle prend en argument la liste des coordonnées issue de la fonction3 et nous retourne une liste qui contient le RMSF à la fin.
Il s’agit donc de différents calculs mathématiques:
    • Un premier parcours de la liste des coordonnées pour calculer la moyenne des coordonnées pour chaque atome et les garder en mémoire dans une liste moy_all, il s’agit de la premiere partie de l’équation du RMSF.
    • Un second parcours de la liste des coordonnées va nous permettre de calculer l’écart-type des coordonnées, il s’agit de la seconde partie de l’équation vue précédemment.
Module requis: math

Fonction 5: plot_RMSF(x, y)
pour une meilleur interprétation du calcul du RMSF, il est necessaire de faire une représentation graphique des résultats. Elle prend en argument: 
    • pour l’axe des abscisses la position des atomes(issue de la fonction 3).
    • pour l’axe des ordonnées l’RMSF(issue de la fonction 4)
A la fin de l’exécution une fenêtre du plot va souvrir.
Module requis: matplotlib

Fonction 6: exit_type()
Il s’agit d’une fonction sans arguments qui s’exécute en fermant la fenêtre du plot. Elle va nous permettre par un simple message affiché sur le terminal de choisir si oui on veut ou pas enregistrer le résultat des calculs du RMSF dans un fichier .txt. Taper 1:Oui, 2: Non. 
Si on choisit de ne pas garder le résultat un message de fin va s’afficher et fermeture du programme. Dans le cas contraire, cette fonction va appeler la fonction write_rmsf().
Module requis: sys

Fonction 6: write_rmsf()
C’est une fonction sans arguments appelée par la fonction précédente. Cette fonction va sauvegarder le résultat des calculs dans un fichier .txt qui contiendra la position de l’atome  dans la protéine et son RMSF. Ce fichier sera enregistré dans le répertoire courant (d’où la fonction a était lancée) sous le nom RMSF_CA.txt ou RMSF_all.txt .
Module requis: os

	III.	Description fichiers input et output:

    1. Fichier input: MD_fit.pdb:
C’est un fichier issue de la simulation de la trajectoire de la protéine. 
On ne l’obtient pas directement mais par conversion grace à gromacs trjconv, la commande typique est la suivante:
gmx trjconv -s md.tpr -f md_skip100_OK.xtc -dt 100 -fit start_prot_only.pdb -o MD_fit.pdb

On converti le fichier binaire de la trajectoire: md.tpr en fichier MD_fit.pdb.
Dans le cas de la protéine 1BTA:
    • On trouve 201 simulations (models) 1 model\100 picosecondes.
    • Le nom de la protéine et autres informations relatives.

    2. Fichier output RMSF_CA.txt ou RMSF_all.txt
l’obtention de ce fichier est optionnel durant le programme. Il contient deux colonnes:
    • Colonne 1: position de l’atome dans la protéine.
    • Colonne 2: RMSF en nm 
      
	IV.	Les modules requis:

    • os: le but principal du module OS est d'interagir avec votre système d'exploitation. Très utile pour créer, supprimer ou déplacer des dossiers et parfois de changer ou trouver le répertoire de travail.
      
    • Sys: le module sys contient des fonctions et des variables spécifiques à l'interpréteur Python lui-même. Ce module est particulièrement intéressant pour récupérer les arguments passés à un script Python lorsque celui-ci est appelé en ligne de commande.
      
    • Matplotlib: Le module matplotlib regroupe un grand nombre de fonctions qui servent à créer des graphiques et les personnaliser (travailler sur les axes, le type de graphique, sa forme et même rajouter du texte).
      
    • Math: le module math est utile pour les manipulations des fonctions et constantes mathématiques de base (sin, cos, exp, pi...).
      
